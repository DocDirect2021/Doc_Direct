package com.projetdam.docdirect.commons;

public class NodesNames {
        public static final String KEY_COLLECTION_PRODUCTS = "users";
        //public static final String KEY_ID = "TOTO";

        public static final String KEY_NOM = "nom";
        public static final String KEY_PRENOM = "prenom";
        public static final String KEY_DateNaiss = "dateNaiss";
        public static final String KEY_TELEPHONE = "telephone";
        public static final String KEY_EMAIL = "email";
        public static final String KEY_AVATAR = "avatar";
        public static final String KEY_ID = "id";
}
