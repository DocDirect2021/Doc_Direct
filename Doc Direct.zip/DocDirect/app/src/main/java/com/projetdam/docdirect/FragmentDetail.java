package com.projetdam.docdirect;


import androidx.fragment.app.Fragment;

public class FragmentDetail extends Fragment {
}
